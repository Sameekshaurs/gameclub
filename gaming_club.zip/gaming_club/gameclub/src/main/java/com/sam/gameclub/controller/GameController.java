package com.sam.gameclub.controller;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sam.gameclub.model.game;
import com.sam.gameclub.repository.GameRepository;
import org.springframework.web.bind.annotation.RequestParam;


@RestController
@RequestMapping(path="/games")
public class GameController {
    @Autowired
    private GameRepository repo;
    @PostMapping 
    public game create(@RequestBody game game){
        game.setId(null);
        game savedGame =repo.save(game);
        return savedGame;
    }
    @GetMapping 
    public List<game>findAll(){
        List<game> games =repo.findAll();
        return games;
    }
    @GetMapping(path="/{id}")
    public game findById(@PathVariable String id){
        game game =repo.findById(id).get();
        return game;
    }

    @PutMapping(path="/{id}")
    public game update(@PathVariable String id,@RequestBody game game){
        game oldgame = repo.findById(id).get();
        oldgame.setName(game.getName());
        oldgame.setDescription(game.getDescription());
        oldgame.setPrice(game.getPrice());

        game updatedGame = repo.save(oldgame);
        return updatedGame;

    }
    @DeleteMapping(path="/{id}")
    public void delete(@PathVariable String id){
        repo.deleteById(id);
    }
    

    
}
